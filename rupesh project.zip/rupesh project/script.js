// Global variables
let cart = [];
let currentUser = null;

// Login functionality
document.addEventListener('DOMContentLoaded', function() {
    // Check if redirected from registration
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('registered') === 'true') {
        const successAlert = document.getElementById('successAlert');
        if (successAlert) {
            successAlert.style.display = 'block';
        }
    }

    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        const emailInput = document.getElementById('email');
        const passwordInput = document.getElementById('password');
        const errorAlert = document.getElementById('errorAlert');
        const errorMessage = document.getElementById('errorMessage');

        // Add input validation
        emailInput.addEventListener('input', function() {
            this.classList.remove('is-invalid');
            if (errorAlert) errorAlert.style.display = 'none';
        });

        passwordInput.addEventListener('input', function() {
            this.classList.remove('is-invalid');
            if (errorAlert) errorAlert.style.display = 'none';
        });

        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const email = emailInput.value;
            const password = passwordInput.value;
            
            // Reset validation states
            emailInput.classList.remove('is-invalid');
            passwordInput.classList.remove('is-invalid');
            
            // Check if user exists and password matches
            const userData = localStorage.getItem('user_' + email);
            if (userData) {
                const user = JSON.parse(userData);
                if (user.password === password) {
                    currentUser = email;
                    localStorage.setItem('currentUser', email);
                    window.location.href = 'menu.html';
                } else {
                    passwordInput.classList.add('is-invalid');
                    if (errorAlert && errorMessage) {
                        errorMessage.textContent = 'Invalid password!';
                        errorAlert.style.display = 'block';
                    }
                }
            } else {
                emailInput.classList.add('is-invalid');
                if (errorAlert && errorMessage) {
                    errorMessage.textContent = 'User not found. Please register first.';
                    errorAlert.style.display = 'block';
                }
            }
        });
    }

    // Registration functionality
    const registerForm = document.getElementById('registerForm');
    if (registerForm) {
        const nameInput = document.getElementById('name');
        
        // Add input event listener for name validation
        nameInput.addEventListener('input', function() {
            if (this.value === '-1') {
                this.setCustomValidity("Name cannot be '-1'");
                this.classList.add('is-invalid');
            } else {
                this.setCustomValidity('');
                this.classList.remove('is-invalid');
            }
        });

        registerForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const name = document.getElementById('name').value;
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirmPassword').value;

            // Validate name
            if (name === '-1') {
                nameInput.classList.add('is-invalid');
                return;
            }

            // Check if user already exists
            if (localStorage.getItem('user_' + email)) {
                alert('Email already registered. Please login instead.');
                window.location.href = 'login.html';
                return;
            }

            if (password !== confirmPassword) {
                alert('Passwords do not match!');
                return;
            }

            // Store user info
            localStorage.setItem('user_' + email, JSON.stringify({
                name: name,
                email: email,
                password: password
            }));

            // Redirect to login with success parameter
            window.location.href = 'login.html?registered=true';
        });
    }

    // Add to cart functionality
    const addToCartButtons = document.querySelectorAll('.add-to-cart');
    if (addToCartButtons.length > 0) {
        // Check if user is logged in
        const currentUser = localStorage.getItem('currentUser');
        if (!currentUser) {
            alert('Please login to add items to cart.');
            window.location.href = 'login.html';
            return;
        }

        addToCartButtons.forEach(button => {
            button.addEventListener('click', function() {
                const item = this.dataset.item;
                const price = parseFloat(this.dataset.price);
                
                cart.push({ item, price });
                localStorage.setItem('cart', JSON.stringify(cart));
                
                alert(`${item} added to cart!`);
            });
        });
    }

    // Payment functionality
    const cardPaymentForm = document.getElementById('cardPaymentForm');
    const upiPaymentForm = document.getElementById('upiPaymentForm');
    const netbankingPaymentForm = document.getElementById('netbankingPaymentForm');
    const codPaymentForm = document.getElementById('codPaymentForm');

    // Check if user is logged in for payment
    if (cardPaymentForm || upiPaymentForm || netbankingPaymentForm || codPaymentForm) {
        const currentUser = localStorage.getItem('currentUser');
        if (!currentUser) {
            alert('Please login to make a payment.');
            window.location.href = 'login.html';
            return;
        }
    }

    // Load cart items
    const savedCart = localStorage.getItem('cart');
    if (savedCart) {
        cart = JSON.parse(savedCart);
        displayCartItems();
    }

    // Card Payment
    if (cardPaymentForm) {
        cardPaymentForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const cardNumber = document.getElementById('cardNumber').value;
            const expiryDate = document.getElementById('expiryDate').value;
            const cvv = document.getElementById('cvv').value;
            const nameOnCard = document.getElementById('nameOnCard').value;

            if (validateCardDetails(cardNumber, expiryDate, cvv)) {
                processPayment('card', {
                    cardNumber,
                    expiryDate,
                    cvv,
                    nameOnCard
                });
            }
        });
    }

    // UPI Payment
    if (upiPaymentForm) {
        upiPaymentForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const upiId = document.getElementById('upiId').value;

            if (validateUPI(upiId)) {
                processPayment('upi', { upiId });
            }
        });
    }

    // Net Banking Payment
    if (netbankingPaymentForm) {
        netbankingPaymentForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const bank = document.getElementById('bank').value;

            if (bank) {
                processPayment('netbanking', { bank });
            }
        });
    }

    // Cash on Delivery
    if (codPaymentForm) {
        codPaymentForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const deliveryInstructions = document.getElementById('deliveryInstructions').value;
            processPayment('cod', { deliveryInstructions });
        });
    }

    // Receipt functionality
    if (window.location.pathname.includes('receipt.html')) {
        const currentUser = localStorage.getItem('currentUser');
        if (!currentUser) {
            alert('Please login to view receipt.');
            window.location.href = 'login.html';
            return;
        }
        displayReceipt();
    }
});

function validateCardDetails(cardNumber, expiryDate, cvv) {
    // Basic validation
    if (cardNumber.length !== 16) {
        alert('Please enter a valid 16-digit card number');
        return false;
    }
    if (!/^\d{2}\/\d{2}$/.test(expiryDate)) {
        alert('Please enter a valid expiry date (MM/YY)');
        return false;
    }
    if (cvv.length !== 3 && cvv.length !== 4) {
        alert('Please enter a valid CVV (3 or 4 digits)');
        return false;
    }
    return true;
}

function validateUPI(upiId) {
    // Basic UPI validation
    if (!upiId.includes('@')) {
        alert('Please enter a valid UPI ID');
        return false;
    }
    return true;
}

function processPayment(method, details) {
    // In a real application, you would send this to a payment gateway
    // For demo purposes, we'll just redirect to receipt
    localStorage.setItem('paymentMethod', method);
    localStorage.setItem('paymentDetails', JSON.stringify(details));
    window.location.href = 'receipt.html';
}

function displayCartItems() {
    const cartItemsContainer = document.getElementById('cart-items');
    const totalAmountElement = document.getElementById('total-amount');
    
    if (cartItemsContainer && totalAmountElement) {
        cartItemsContainer.innerHTML = '';
        let total = 0;
        
        cart.forEach(item => {
            const itemElement = document.createElement('div');
            itemElement.className = 'mb-2';
            itemElement.innerHTML = `
                <div class="d-flex justify-content-between">
                    <span>${item.item}</span>
                    <span>$${item.price.toFixed(2)}</span>
                </div>
            `;
            cartItemsContainer.appendChild(itemElement);
            total += item.price;
        });
        
        totalAmountElement.textContent = total.toFixed(2);
    }
}

function displayReceipt() {
    const receiptItemsContainer = document.getElementById('receipt-items');
    const receiptTotalElement = document.getElementById('receipt-total');
    const customerNameElement = document.getElementById('customer-name');
    const customerEmailElement = document.getElementById('customer-email');
    const orderDateElement = document.getElementById('order-date');
    
    if (receiptItemsContainer && receiptTotalElement) {
        // Load cart items
        const savedCart = localStorage.getItem('cart');
        if (savedCart) {
            cart = JSON.parse(savedCart);
        }
        
        // Display items
        receiptItemsContainer.innerHTML = '';
        let total = 0;
        
        cart.forEach(item => {
            const itemElement = document.createElement('div');
            itemElement.className = 'mb-2';
            itemElement.innerHTML = `
                <div class="d-flex justify-content-between">
                    <span>${item.item}</span>
                    <span>$${item.price.toFixed(2)}</span>
                </div>
            `;
            receiptItemsContainer.appendChild(itemElement);
            total += item.price;
        });
        
        receiptTotalElement.textContent = total.toFixed(2);
        
        // Display customer info
        const currentUser = localStorage.getItem('currentUser');
        if (currentUser) {
            const userInfo = JSON.parse(localStorage.getItem('user_' + currentUser));
            if (userInfo) {
                customerNameElement.textContent = userInfo.name;
                customerEmailElement.textContent = userInfo.email;
            }
        }
        
        // Display order date
        const now = new Date();
        orderDateElement.textContent = now.toLocaleDateString() + ' ' + now.toLocaleTimeString();
        
        // Clear cart after displaying receipt
        localStorage.removeItem('cart');
        cart = [];
    }
} 